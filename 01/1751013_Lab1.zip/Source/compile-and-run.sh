g++ shape.h shape.cpp -o OpenGlApp -lglfw -lGLEW -lglut -lGLU -lGL && ./OpenGlApp
